Les algorithmes de Jarvis et des demi-plans sont implémentés. 

Pour pouvoir afficher le resultat de l'algorithme des demi-plans j'ai crée une méthode de conversion du format de liste de liste en liste normale
Mais, cette méthode ne fonctionne que quand le premier point de la liste est bien le premier point du graphe. Donc, 
certains cas ne sont pas proprement affichés.

